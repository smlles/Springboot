package com.korea.rnBoard;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class RnBoardApplicationTests {

	@Test
	void contextLoads() {
	}

}
