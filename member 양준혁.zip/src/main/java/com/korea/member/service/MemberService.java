package com.korea.member.service;

import java.util.List;
import java.util.Optional;
import java.util.stream.Collectors;

import org.springframework.stereotype.Service;

import com.korea.member.DTO.MemberDTO;
import com.korea.member.model.MemberEntity;
import com.korea.member.repository.MemberRepository;

import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;

@Service
@Slf4j
@RequiredArgsConstructor
public class MemberService {

	private final MemberRepository repository;
	
	//전체 회원 조회 
	public List<MemberDTO> allMember(){
		
		return repository.findAll().stream().map(MemberDTO::new).collect(Collectors.toList());
		
	}
	//특정 회원 조회

//	public List<MemberDTO> findByEmail(String email){
//		Optional<MemberEntity> entity = repository.findByEmail(email);
//		if(entity!=null) {
//			
//		}
//		
//		
//	}
	/// 회원 추가
	public List<MemberDTO> createMember(MemberEntity entity){
		repository.save(entity);
		
		return repository.findAll().stream().map(MemberDTO::new).collect(Collectors.toList());
	}
	
	//이메일을 통해 비밀번호 변경
	
	//회원 아이디 삭제
	public List<MemberDTO> deleteMember(MemberEntity entity){
		if(repository.findById(entity.getId())!=null) {
			repository.delete(entity);
		}
		
		
		return repository.findAll().stream().map(MemberDTO::new).collect(Collectors.toList());
	}
}
